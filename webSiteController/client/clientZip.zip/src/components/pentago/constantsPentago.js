const NUM_ROWS = 6;
const NUM_COLUMNS = 6;

export { NUM_ROWS, NUM_COLUMNS };
